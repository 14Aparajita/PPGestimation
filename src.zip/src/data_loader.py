"""
data_loader.py
Utilities to inspect and stream windows from a large .h5 dataset.
Adjust dataset keys to match your .h5 file structure.
"""
import h5py
import numpy as np

def inspect_h5(h5_path):
    """
    Print top-level keys and shapes inside the .h5 file.
    """
    with h5py.File(h5_path, "r") as f:
        def print_group(g, indent=0):
            for k, v in g.items():
                if isinstance(v, h5py.Dataset):
                    print("  " * indent + f"- {k} (Dataset) shape={v.shape} dtype={v.dtype}")
                else:
                    print("  " * indent + f"- {k} (Group)")
                    print_group(v, indent + 1)
        print_group(f)

def iter_h5_windows(h5_path, window_key="windows", label_key="labels", chunk_size=512):
    """
    Generator yields (windows_chunk, labels_chunk).
    Each windows_chunk has shape (n_windows, window_len) and
    labels_chunk has shape (n_windows, 3) assumed as [SBP, DBP, ABP].
    """
    with h5py.File(h5_path, "r") as f:
        if window_key not in f or label_key not in f:
            raise KeyError(f"Keys not found in HDF5. Found top-level keys: {list(f.keys())}")
        w = f[window_key]
        lbl = f[label_key]
        total = w.shape[0]
        for i in range(0, total, chunk_size):
            j = min(total, i + chunk_size)
            windows = w[i:j]        # memory: chunk_size * window_len
            labels = lbl[i:j]
            yield windows, labels

def load_small_sample(h5_path, window_key="windows", label_key="labels", n=1000):
    """
    Load a small sample (first n windows) into memory for prototyping/EDA.
    """
    with h5py.File(h5_path, "r") as f:
        w = f[window_key][:n]
        lbl = f[label_key][:n]
    return w, lbl
