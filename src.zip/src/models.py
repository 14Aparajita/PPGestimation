"""
models.py
Model training, hyperparameter tuning, ensembling and evaluation utilities.
This module focuses on regression (SBP, DBP, ABP) using scikit-learn.
"""
from sklearn.model_selection import train_test_split, GridSearchCV, KFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsRegressor
from sklearn.svm import SVR
from sklearn.linear_model import Ridge
from sklearn.ensemble import RandomForestRegressor, VotingRegressor, StackingRegressor
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
import numpy as np

def split_features_labels(df, target_cols=['SBP','DBP','ABP']):
    X = df.drop(columns=[c for c in target_cols if c in df.columns]).values
    y = df[target_cols].values if all(c in df.columns for c in target_cols) else None
    return X, y

def evaluate_regression_model(model, X, y):
    preds = model.predict(X)
    if preds.ndim == 1:
        preds = preds.reshape(-1,1)
    if y.ndim == 1:
        y = y.reshape(-1,1)
    metrics = {}
    # compute per-target MAE/RMSE/R2
    for i in range(y.shape[1]):
        metrics[i] = {
            "MAE": float(mean_absolute_error(y[:,i], preds[:,i])),
            "RMSE": float(mean_squared_error(y[:,i], preds[:,i], squared=False)),
            "R2": float(r2_score(y[:,i], preds[:,i]))
        }
    # aggregate (mean)
    metrics['mean_MAE'] = float(np.mean([metrics[i]['MAE'] for i in range(y.shape[1])]))
    metrics['mean_RMSE'] = float(np.mean([metrics[i]['RMSE'] for i in range(y.shape[1])]))
    metrics['mean_R2'] = float(np.mean([metrics[i]['R2'] for i in range(y.shape[1])]))
    return metrics

def train_and_tune(X, y, target_idx=0, cv_splits=4):
    """
    Train tuned regressors for a single target (e.g., target_idx=0 => SBP column).
    Returns best estimators and a fitted voting ensemble.
    """
    y_single = y[:, target_idx]

    X_train, X_test, y_train, y_test = train_test_split(X, y_single, test_size=0.2, random_state=42)

    # Pipelines
    pipe_knn = Pipeline([('scaler', StandardScaler()), ('knn', KNeighborsRegressor())])
    param_knn = {'knn__n_neighbors': [3,5,7,9], 'knn__weights': ['uniform','distance']}

    pipe_svr = Pipeline([('scaler', StandardScaler()), ('svr', SVR())])
    param_svr = {'svr__C': [0.1,1,10], 'svr__gamma': ['scale','auto'], 'svr__epsilon':[0.1,0.2]}

    pipe_rf = Pipeline([('scaler', StandardScaler()), ('rf', RandomForestRegressor(n_jobs=-1, random_state=42))])
    param_rf = {'rf__n_estimators': [100,200], 'rf__max_depth':[10,20,None]}

    cv = KFold(n_splits=cv_splits, shuffle=True, random_state=42)
    gs_knn = GridSearchCV(pipe_knn, param_knn, cv=cv, scoring='neg_mean_absolute_error', n_jobs=-1)
    gs_svr = GridSearchCV(pipe_svr, param_svr, cv=cv, scoring='neg_mean_absolute_error', n_jobs=-1)
    gs_rf  = GridSearchCV(pipe_rf, param_rf, cv=cv, scoring='neg_mean_absolute_error', n_jobs=-1)

    gs_knn.fit(X_train, y_train)
    gs_svr.fit(X_train, y_train)
    gs_rf.fit(X_train, y_train)

    voting = VotingRegressor(estimators=[
        ('knn', gs_knn.best_estimator_),
        ('svr', gs_svr.best_estimator_),
        ('rf', gs_rf.best_estimator_)
    ], n_jobs=-1)
    voting.fit(X_train, y_train)

    # stacking with ridge as final estimator
    stacking = StackingRegressor(estimators=[
        ('knn', gs_knn.best_estimator_),
        ('svr', gs_svr.best_estimator_),
        ('rf', gs_rf.best_estimator_)
    ], final_estimator=Ridge(), n_jobs=-1)
    stacking.fit(X_train, y_train)

    # evaluate on test splits
    def metrics_for(m):
        preds = m.predict(X_test)
        return {
            'MAE': float(mean_absolute_error(y_test, preds)),
            'RMSE': float(mean_squared_error(y_test, preds, squared=False)),
            'R2': float(r2_score(y_test, preds))
        }

    results = {
        'knn_best': (gs_knn.best_estimator_, metrics_for(gs_knn.best_estimator_)),
        'svr_best': (gs_svr.best_estimator_, metrics_for(gs_svr.best_estimator_)),
        'rf_best':  (gs_rf.best_estimator_, metrics_for(gs_rf.best_estimator_)),
        'voting':   (voting, metrics_for(voting)),
        'stacking': (stacking, metrics_for(stacking)),
        'X_test': X_test,
        'y_test': y_test
    }
    return results
