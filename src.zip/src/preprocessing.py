"""
preprocessing.py
Denoising, normalization, segmentation utilities for PPG signals.
Uses bandpass + wavelet denoising fallback; optionally can be replaced with a TQWT implementation.
"""
import numpy as np
from scipy.signal import butter, filtfilt, find_peaks, savgol_filter
import pywt

def bandpass_filter(sig, fs, low=0.5, high=8.0, order=4):
    nyq = 0.5 * fs
    lowcut = low / nyq
    highcut = high / nyq
    b, a = butter(order, [lowcut, highcut], btype="band")
    return filtfilt(b, a, sig)

def wavelet_denoise(sig, wavelet="db6", level=None):
    if level is None:
        level = 3
    coeffs = pywt.wavedec(sig, wavelet, mode="symmetric")
    sigma = (np.median(np.abs(coeffs[-level])) / 0.6745) if len(coeffs) > level else (np.std(sig) + 1e-8)
    uthresh = sigma * np.sqrt(2 * np.log(len(sig)))
    denoised_coeffs = [coeffs[0]] + [pywt.threshold(c, value=uthresh, mode="soft") for c in coeffs[1:]]
    denoised = pywt.waverec(denoised_coeffs, wavelet, mode="symmetric")
    # ensure length matches input (waverec may change length by a few samples)
    return denoised[:len(sig)]

def denoise_ppg_window(window, fs, use_tqwt=False):
    """
    Denoise a single PPG window.
    Default path: bandpass (0.5-8 Hz) -> wavelet denoise -> Savitzky-Golay smooth
    If you have a TQWT implementation, replace with TQWT denoising pipeline by setting use_tqwt=True.
    """
    sig = np.asarray(window, dtype=float)
    try:
        bp = bandpass_filter(sig, fs)
    except Exception:
        # fallback to simple highpass if filtfilt fails for short signals
        bp = sig - np.mean(sig)
    den = wavelet_denoise(bp)
    # smoothing (window must be odd; ensure odd)
    wlen = 9 if len(den) >= 9 else (len(den) - 1 if (len(den) % 2 == 0) else len(den))
    if wlen >= 5:
        den = savgol_filter(den, window_length=wlen, polyorder=3)
    return den

def zscore_normalize(window):
    w = np.asarray(window, dtype=float)
    mu = np.mean(w)
    sigma = np.std(w) + 1e-8
    return (w - mu) / sigma

def minmax_normalize(window):
    w = np.asarray(window, dtype=float)
    mn = np.min(w)
    mx = np.max(w)
    denom = (mx - mn) if (mx - mn) != 0 else 1.0
    return (w - mn) / denom

def detect_peaks_ppg(sig, fs, min_hr=40, max_hr=200, prominence=None):
    """
    Detect systolic peaks in PPG window.
    Returns indices of peaks.
    """
    if prominence is None:
        prominence = 0.3 * (np.max(sig) - np.min(sig) + 1e-8)
    min_dist_samples = int(fs * 60 / max_hr)
    peaks, props = find_peaks(sig, distance=min_dist_samples, prominence=prominence)
    return peaks, props
