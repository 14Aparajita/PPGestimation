"""
features.py
Feature extraction for PPG windows. Produces a dictionary of features for each window.
Includes time-domain, derivative-based, and simple frequency-domain features.
"""
import numpy as np
from scipy.signal import find_peaks
from scipy.fft import rfft, rfftfreq
from scipy.stats import skew, kurtosis

def _second_derivative(sig):
    # APG (acceleration plethysmogram) approximation using discrete second derivative
    return np.gradient(np.gradient(sig))

def extract_morphological_features(ppg_window, fs):
    x = np.asarray(ppg_window, dtype=float)
    features = {}

    # Basic statistics
    features['mean'] = np.mean(x)
    features['std'] = np.std(x)
    features['min'] = np.min(x)
    features['max'] = np.max(x)
    features['skew'] = float(skew(x))
    features['kurtosis'] = float(kurtosis(x))

    # Peak & trough
    # Use prominence relative to dynamic range
    prom = 0.25 * (features['max'] - features['min'] + 1e-8)
    peaks, _ = find_peaks(x, prominence=prom, distance=int(0.4 * fs))
    troughs, _ = find_peaks(-x, prominence=prom, distance=int(0.4 * fs))

    # Peak-based features (window-level aggregation)
    if len(peaks) >= 1:
        systolic_values = x[peaks]
        features['systolic_peak_mean'] = float(np.mean(systolic_values))
        features['systolic_peak_std'] = float(np.std(systolic_values))
        features['peak_count'] = int(len(peaks))
        features['pp_amp'] = float(np.mean(systolic_values) - np.mean(x))
    else:
        features['systolic_peak_mean'] = 0.0
        features['systolic_peak_std'] = 0.0
        features['peak_count'] = 0
        features['pp_amp'] = 0.0

    # Peak-to-peak intervals => heart-rate proxies
    if len(peaks) >= 2:
        ppi = np.diff(peaks) / fs
        features['mean_ppi'] = float(np.mean(ppi))
        features['std_ppi'] = float(np.std(ppi))
        features['median_ppi'] = float(np.median(ppi))
    else:
        features['mean_ppi'] = 0.0
        features['std_ppi'] = 0.0
        features['median_ppi'] = 0.0

    # Derivative features (VPG)
    dv = np.gradient(x)
    features['dv_mean'] = float(np.mean(dv))
    features['dv_max'] = float(np.max(dv))
    features['dv_min'] = float(np.min(dv))
    features['dv_skew'] = float(skew(dv))
    features['dv_kurtosis'] = float(kurtosis(dv))

    # Second derivative (APG) based features: locate a,b,c,d,e peaks if possible
    apg = _second_derivative(x)
    # detect positive peaks (a, c, e) and negative peaks (b, d)
    a_peaks, _ = find_peaks(apg, distance=int(0.2 * fs))
    neg_peaks, _ = find_peaks(-apg, distance=int(0.2 * fs))
    # simple ratios of interest: if we can find first few peaks
    features['apg_a_count'] = int(len(a_peaks))
    features['apg_neg_count'] = int(len(neg_peaks))
    # amplitude ratios if first two positive & negative exist
    if len(a_peaks) >= 1 and len(neg_peaks) >= 1:
        a1 = apg[a_peaks[0]]
        b1 = apg[neg_peaks[0]]
        # augmentation index like: b/a (take abs)
        features['b_by_a'] = float(abs(b1) / (abs(a1) + 1e-8))
    else:
        features['b_by_a'] = 0.0

    # Area under curve
    features['auc'] = float(np.trapz(x))

    # Frequency domain: dominant frequency and energy in band
    N = len(x)
    if N > 1:
        yf = np.abs(rfft(x))
        xf = rfftfreq(N, 1.0 / fs)
        # dominant freq
        idx = np.argmax(yf)
        features['dominant_freq'] = float(xf[idx])
        # energy in 0.5-4 Hz and 4-8 Hz bands
        band1 = ((xf >= 0.5) & (xf <= 4.0))
        band2 = ((xf > 4.0) & (xf <= 8.0))
        features['energy_0_4'] = float(np.sum(yf[band1]) / (np.sum(yf) + 1e-8))
        features['energy_4_8'] = float(np.sum(yf[band2]) / (np.sum(yf) + 1e-8))
    else:
        features['dominant_freq'] = 0.0
        features['energy_0_4'] = 0.0
        features['energy_4_8'] = 0.0

    return features

def extract_features_for_batch(windows_batch, fs):
    """
    windows_batch: np.array shape (n_windows, window_len)
    returns: list of dicts (features) and np.array labels if labels passed externally
    """
    feats = []
    for i in range(windows_batch.shape[0]):
        f = extract_morphological_features(windows_batch[i], fs)
        feats.append(f)
    return feats
