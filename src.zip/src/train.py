"""
train.py
End-to-end runner:
- Streams data from .h5
- Denoises and normalizes windows
- Extracts features and writes a parquet file
- Loads features to train regressors and ensembles for SBP/DBP/ABP
- Saves best models and prints evaluation
Adjust HDF5 keys and fs before running.
"""
import os
import numpy as np
import pandas as pd
from tqdm import tqdm

from src.data_loader import iter_h5_windows, inspect_h5, load_small_sample
from src.preprocessing import denoise_ppg_window, zscore_normalize, minmax_normalize
from src.features import extract_features_for_batch
from src.utils import save_features_to_parquet, save_model, load_features_from_parquet
from src.models import split_features_labels, train_and_tune, evaluate_regression_model


# ---------- USER CONFIG ----------
h5_path = "/home/user1/komendra/ml_ppg_data/trial/data/MIMIC-III_ppg_dataset.h5"
window_key = "ppg"            # from your inspect output
label_key = "label"           # from your inspect output
fs = 125                      # assumed sampling frequency; change if different
chunk_size = 1024             # increase if you have RAM; reduces I/O calls
features_parquet = "outputs/features.parquet"
save_models_dir = "outputs/models"
# ---------------------------------

os.makedirs(save_models_dir, exist_ok=True)
os.makedirs("outputs", exist_ok=True)

def build_feature_table_from_h5(h5_path, window_key, label_key, fs, out_path, chunk_size=512, max_windows=None):
    """
    Stream windows from HDF5, denoise, normalize, extract features, and write to parquet.
    max_windows: optional limit for prototyping.
    """
    features_accum = []
    labels_accum = []
    total_processed = 0
    print("Inspecting HDF5 keys (top-level):")
    inspect_h5(h5_path)

    for windows_chunk, labels_chunk in iter_h5_windows(h5_path, window_key, label_key, chunk_size=chunk_size):
        # windows_chunk shape (n, window_len)
        # denoise + normalize each window
        denoised = []
        for w in windows_chunk:
            den = denoise_ppg_window(w, fs)
            norm = zscore_normalize(den)
            denoised.append(norm)
        denoised = np.stack(denoised, axis=0)
        # extract features for chunk
        feats_chunk = extract_features_for_batch(denoised, fs)
        features_accum.extend(feats_chunk)
        labels_accum.extend(labels_chunk.tolist())
        total_processed += denoised.shape[0]
        print(f"Processed windows: {total_processed}")
        if max_windows is not None and total_processed >= max_windows:
            break
    labels_arr = np.array(labels_accum)
    df = save_features_to_parquet(features_accum, labels_arr, out_path)
    print("Saved features to:", out_path)
    return df

def train_all_targets(features_parquet, save_models_dir):
    df = load_features_from_parquet(features_parquet)
    X, y = split_features_labels(df, target_cols=['SBP','DBP','ABP'])
    print("Feature matrix shape:", X.shape, "Targets shape:", y.shape)

    # Train separate tuned models for each target and save winners
    best_models = {}
    for target_idx, target_name in enumerate(['SBP','DBP','ABP']):
        print(f"\nTraining and tuning model chain for {target_name} (index {target_idx}) ...")
        results = train_and_tune(X, y, target_idx=target_idx, cv_splits=4)
        # choose stacking or voting based on metric (MAE) on held-out test in results
        candidates = ['voting','stacking']
        candidate_scores = {}
        for c in candidates:
            candidate_scores[c] = results[c][1]['MAE']
        chosen = min(candidate_scores, key=candidate_scores.get)
        chosen_model = results[chosen][0]
        print(f"Chosen ensemble for {target_name}: {chosen} with MAE={candidate_scores[chosen]:.4f}")
        # Save chosen model
        model_path = os.path.join(save_models_dir, f"{target_name}_ensemble.joblib")
        save_model(chosen_model, model_path)
        # Evaluate chosen on held-out
        test_X = results['X_test']
        test_y = results['y_test']
        preds = chosen_model.predict(test_X)
        from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
        print(f"Test MAE {target_name}: {mean_absolute_error(test_y, preds):.4f}")
        print(f"Test RMSE {target_name}: {mean_squared_error(test_y, preds, squared=False):.4f}")
        print(f"Test R2 {target_name}: {r2_score(test_y, preds):.4f}")
        best_models[target_name] = model_path
    return best_models

if __name__ == "__main__":
    # If features parquet doesn't exist, build it
    if not os.path.exists(features_parquet):
        print("Features parquet not found. Building features from HDF5 (this may take long)...")
        df = build_feature_table_from_h5(h5_path, window_key, label_key, fs, features_parquet, chunk_size=chunk_size)
    else:
        print("Found existing features parquet. Loading...")

    print("Starting training pipeline...")
    best_models = train_all_targets(features_parquet, save_models_dir)
    print("Saved models:", best_models)
    print("Done.")
