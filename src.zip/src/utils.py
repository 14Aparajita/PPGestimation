"""
utils.py
Helpers for saving/loading intermediate artifacts, logging, and feature file utilities.
"""
import pandas as pd
import joblib
import os
import numpy as np
from typing import List

def save_features_to_parquet(features_list, labels_array, out_path="outputs/features.parquet"):
    """
    features_list: list of dicts
    labels_array: np.array shape (n, 2) or (n, 3) with SBP, DBP, (ABP)
    If labels_array has 2 columns, compute ABP = (SBP + 2*DBP) / 3 and append.
    """
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    df = pd.DataFrame(features_list)
    if labels_array is not None:
        labels_array = np.asarray(labels_array)
        if labels_array.ndim == 1:
            # single column -> treat as SBP
            df['SBP'] = labels_array
            df['DBP'] = None
            df['ABP'] = None
        else:
            if labels_array.shape[1] == 2:
                # assume [SBP, DBP] — compute ABP (MAP)
                sbp = labels_array[:, 0].astype(float)
                dbp = labels_array[:, 1].astype(float)
                abp = (sbp + 2.0 * dbp) / 3.0
                df['SBP'] = sbp
                df['DBP'] = dbp
                df['ABP'] = abp
            elif labels_array.shape[1] >= 3:
                # if there are 3 columns, take first 3 as SBP,DBP,ABP
                df[['SBP', 'DBP', 'ABP']] = pd.DataFrame(labels_array[:, :3], index=df.index)
            else:
                # fallback: try to unpack columns safely
                for i in range(labels_array.shape[1]):
                    df[f"label_{i}"] = labels_array[:, i]
    df.to_parquet(out_path, engine="fastparquet")


    return df


def load_features_from_parquet(path="outputs/features.parquet"):
    return pd.read_parquet(path, engine="fastparquet")

def save_model(model, out_path="outputs/models/best_model.joblib"):
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    joblib.dump(model, out_path)

def load_model(path="outputs/models/best_model.joblib"):
    return joblib.load(path)
